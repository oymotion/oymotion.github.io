/*
* Copyright 2017, OYMotion Inc.
* All rights reserved.
*
* IMPORTANT: Your use of this Software is limited to those specific rights
* granted under the terms of a software license agreement between you and
* OYMotion.  You may not use this Software unless you agree to abide by the
* terms of the License. The License limits your use, and you acknowledge,
* that the Software may not be modified, copied or distributed unless used
* solely and exclusively in conjunction with an OYMotion product.  Other
* than for the foregoing purpose, you may not use, reproduce, copy, prepare
* derivative works of, modify, distribute, perform, display or sell this
* Software and/or its documentation for any purpose.
*
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
* "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
* LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
* FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
* COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
* INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
* BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
* OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
* AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
* OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
* THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH
* DAMAGE.
*
*/
#ifndef __ADAPTERMANAGER_H__
#define __ADAPTERMANAGER_H__
//#include "OYM_NIF.h"
//#include <OYM_Log.h>
//#include "DiscoveryService.h"
//#include "RemoteDevice.h"

#include "oym_types.h"
#include "OYM_Callback.h"
#include "list"
using namespace std;

#define GFORCEDLL
#ifdef GFORCEDLL
#define EXPORT __declspec(dllexport) 
#else
#define EXPORT __declspec(dllimport)
#endif

#define MODUAL_TAG_AM "AdaperManager"
//#define ADAPTERMANAGER_EVENT (EVENT_MASK_LINK_PARA_UPDATE_MSG | EVENT_MASK_AUTH_COMPLETE_MSG | EVENT_MASK_SLAVE_REQUESTED_SECURITY_MSG | EVENT_MASK_INTERNAL_DEVICE_FOUND | EVENT_MASK_INTERNAL_SCAN_FINISHED | EVENT_MASK_GAP_LINK_ESTABLISHED_MSG)

typedef void(*PTGFORCEDATA)(OYM_PUINT8 pData, OYM_UINT16 length);
class OYM_RemoteDevice;
class OYM_Discovery_Service;
class OYM_Log;
class OYM_NPI_Interface;

class EXPORT OYM_AdapterManager : public OYM_CallBack
{
public:
	//OYM_AdapterManager(OYM_NPI_Interface* nif_interface);
	OYM_AdapterManager();
	~OYM_AdapterManager();

	OYM_STATUS Init();
	OYM_STATUS Init(OYM_UINT8 portNum);
	OYM_STATUS Deinit();
	OYM_STATUS StartScan();
	OYM_STATUS StopScan();
	OYM_STATUS OnDeviceFound(BLE_DEVICE new_device);
	OYM_STATUS Connect(OYM_PUINT8 addr, UINT8 addr_type);
	OYM_STATUS OnConnect(OYM_PUINT8 data, OYM_UINT16 length);
	OYM_UINT8	WaitForScanFinished();
	OYM_STATUS OnEvent(OYM_UINT32 event, OYM_PUINT8 data, OYM_UINT16 length);
	OYM_STATUS RegistGforceData(PTGFORCEDATA p_DataFun);
	OYM_STATUS OnScanResult(OYM_PUINT8 data, OYM_UINT16 length)
	{
		return OYM_FAIL;
	}

	OYM_STATUS OnScanFinished();

private:
	OYM_NPI_Interface* mInterface;
	OYM_Log* mLog;
	OYM_Discovery_Service* mDS;
	list<OYM_RemoteDevice*> mAvailabeDevice;
	PTGFORCEDATA mPTgForceDataFunction;
	//BOOL mScanFinishFlag;
	HANDLE mScanFinishEvent;
};
#endif