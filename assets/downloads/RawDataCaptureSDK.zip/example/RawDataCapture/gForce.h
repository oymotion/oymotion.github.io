#ifndef __GFORCE_H__
#define __GFORCE_H__

#include "oym_types.h"
#include "OYM_Callback.h"
#include "AdapterManager.h"

#endif /* __GFORCE_H__ */