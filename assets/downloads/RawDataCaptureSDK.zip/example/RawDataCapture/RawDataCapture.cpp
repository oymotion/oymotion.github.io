/*
* Copyright 2017, OYMotion Inc.
* All rights reserved.
*
* IMPORTANT: Your use of this Software is limited to those specific rights
* granted under the terms of a software license agreement between you and
* OYMotion.  You may not use this Software unless you agree to abide by the
* terms of the License. The License limits your use, and you acknowledge,
* that the Software may not be modified, copied or distributed unless used
* solely and exclusively in conjunction with an OYMotion product.  Other
* than for the foregoing purpose, you may not use, reproduce, copy, prepare
* derivative works of, modify, distribute, perform, display or sell this
* Software and/or its documentation for any purpose.
*
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
* "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
* LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
* FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
* COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
* INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
* BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
* OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
* AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
* OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
* THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH
* DAMAGE.
*
*/
// gForceSample.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "windows.h"
#include "conio.h"
#include <stdio.h>
#include "gForce.h"
#include "dos.h"
#include "stdlib.h"


//#pragma comment(lib,"./dll/gForceSDK.lib")

#define EMGDATA_EVENT_TYPE_INDEX	6	// minor data index in received notify data
#define EMGDATA_LENGTH_INDEX		7	// for protocol ,lenght index,the value of length inclue emg data and package id data
#define EMGDATA_CRC_INDEX		8	// crc data index, crc  for emg data and package id
#define EMGDATA_PACKAGEID_INDEX		9	// package id index in received notify data
#define EMGDATA_VALIDDATA_INDEX		10	//valid emg data index

// valid data is emgdata + head data + packageid
#define EMGDATA_LENGTH				128		// emg data length
#define EMGDATA_HEAD_LENGTH			3		// head data length
#define EMGDATA_PACKAGEID_LENGTH		1		// package id length

static void ProcessGforceData(OYM_PUINT8 pData, OYM_UINT16 length);
static OYM_UINT8 CheckSum(OYM_PUINT8 data, OYM_UINT8 length);        // calculate checksum 


int _tmain(int charc, char* argv[]) {
	OYM_STATUS status;
	UINT8 comNum;
	printf("Please Enter COM num:");
	scanf_s("%u", &comNum);
	OYM_AdapterManager* am = new OYM_AdapterManager();
	status = am->Init(comNum);
	if (!OYM_SUCCEEDED) {
		return -2;
	}
	am->RegistGforceData(ProcessGforceData);
	OYM_UINT8 gForce_count;
	do {
		status = am->StartScan();
		if (!OYM_SUCCEEDED) {
			printf("[ERROR] OYM_AdapterManager::StartScanFailed\n");
			return -2;
		}
		gForce_count = am->WaitForScanFinished();  //wait for scan finished, 15s to timeout.
	} while (gForce_count == 0);

	while (1) {
		Sleep(1000);
	}
	return 0;
}

/**
* @brief callback function ,used to process gforce raw data
* @param  data[in]:data received from SDK
*         length[in]: the length of data
*
* Data format:
*--------------------------------------------------------------------------------------------------
*| Index|  0 ~ 5                       | 6            | 7       |8    |9           |  10 ~ 137    |
*--------------------------------------------------------------------------------------------------
*| value| Status Msg(user can ignore)  | event type   | length  |crc  | package id |  emg rawdata |
*--------------------------------------------------------------------------------------------------
*/
void ProcessGforceData(OYM_PUINT8 data, OYM_UINT16 length)
{
	// If received emg data length is not equal to 138, something is wrong, and just drop it
	if (length != 138) {
		printf("[ERROR] Received bad EMG data!!!!\n");
		return;
	}
	//add code to process gForce rawdata
	static BOOL b_GetFirstPackage = FALSE;
	static OYM_UINT8 s_packageId = 0;
	static OYM_UINT8 s_ReceivedataNum = 0;
	s_ReceivedataNum = (s_ReceivedataNum + 1) % 10;
	if (b_GetFirstPackage == FALSE) {                        // first time get into this function
		b_GetFirstPackage = TRUE;
		system("cls");
		s_packageId = data[EMGDATA_PACKAGEID_INDEX];       // get the first package id
		printf("[INFO] Succeeded in connecting to gForce!\n");
		printf("---------------------------------------------\n");
	}
	else {
		UINT8 crcData = CheckSum(&data[EMGDATA_PACKAGEID_INDEX], 129);
		if (crcData == data[EMGDATA_CRC_INDEX]) {
			if (s_ReceivedataNum == 0) {
				printf("\r");
				for (UINT8 index = 0; index < 8; index++) {
					printf("%d, ", data[EMGDATA_VALIDDATA_INDEX + index]);
				}
			}
		}
		else {
			printf("[Error] crc checks error!\n");
		}

	}
}


//crc checksum
UINT8 CheckSum(UINT8* data, UINT8 length)
{
	UINT8 cs = 0;
	while (length--) {
		cs ^= *data++;
	}
	return cs;
}

