# gForce SDK User Guide

## The gForce SDK is based on windows platform.

1. Plug the BLE dongle and install the driver 

    On many Windows computers, the driver will be installed automatically 
    after the dongle is plugged. If not, please manually install it from 
    folder `BLEDongleDriver`.

    You need to verify whether the BLE dongle is plugged in, as well as 
    the dongle driver has been installed correctly by openning the 
    `Device Manager` and checking if the dongle appears under 
    `Port(COM & LPT)`.

2. Build and run the example application

    Open `example\gForceSDKExample.sln` in Visual Studio 2013, and it
    includes a project named `RawDataCapture`, which is a program that 
    captures the 8-channel EMG raw data from gForce. You may build and
    run it by you own
