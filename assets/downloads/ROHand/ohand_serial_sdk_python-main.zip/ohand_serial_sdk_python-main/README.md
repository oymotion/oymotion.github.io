# OHand SDK Python

Python APIs for OHand control.

## Installation

* Installing from source

```sh
# Linux
cd ohand_serial_sdk_python
python3 -m pip install -e .
```

## Example

```sh
cd ohand_serial_sdk_python/examples/simple_control
python3 simple_control.py
```
